package task01a;

public class Task01a {

	public static void main(String[] args) {

		double z = 5 + Math.sin(80 * Math.PI / 180);

		System.out.printf("%.15f\n", z);
	}

}
