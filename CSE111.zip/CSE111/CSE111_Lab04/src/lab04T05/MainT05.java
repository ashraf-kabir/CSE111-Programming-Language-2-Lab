package lab04T05;

public class MainT05 {

	public static void main(String[] args) {
		
		Task05 T05Obj = new Task05();
		
		T05Obj.methodA();
	}

}
