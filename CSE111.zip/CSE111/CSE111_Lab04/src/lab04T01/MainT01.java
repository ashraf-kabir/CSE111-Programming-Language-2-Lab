package lab04T01;

public class MainT01 {

	public static void main(String[] args) {
		
		Task01 T01Obj = new Task01();
		
		T01Obj.methodA();
		T01Obj.methodB();
		T01Obj.methodA();
		T01Obj.methodB();
	}

}
