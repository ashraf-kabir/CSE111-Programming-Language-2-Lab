package lab04T03;

public class MainT03 {

	public static void main(String[] args) {
		
		Task03 T03Obj = new Task03();
		
		T03Obj.methodA();
		T03Obj.methodA();
		T03Obj.methodA();
		T03Obj.methodA();
		T03Obj.methodA();
	}

}
