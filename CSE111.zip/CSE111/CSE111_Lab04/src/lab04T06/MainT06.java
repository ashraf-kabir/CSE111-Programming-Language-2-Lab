package lab04T06;

public class MainT06 {
	public static void main(String[] args) {
		
		Task06 fT3A = new Task06();
		
		fT3A.methodA();
		fT3A.methodB(6, 8);
		
	}

}
