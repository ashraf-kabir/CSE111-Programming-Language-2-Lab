package lab04T04;

public class MainT04 {

	public static void main(String[] args) {
		
		Task04 T04Obj = new Task04();
		
		T04Obj.methodA();
		T04Obj.methodA();
		T04Obj.methodA();
		T04Obj.methodA();
		T04Obj.methodA();
	}

}
