package task12;

public class MainT12 {

	public static void main(String[] args) {
		
		FinalT6A q1 = new FinalT6A(2,1);
		q1.methodA();
		q1.methodA();
	
	}

}
