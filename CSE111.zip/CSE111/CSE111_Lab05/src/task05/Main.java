package task05;

public class Main {
	
	public static void main(String[] args) {
		Task05 q1 = new Task05(2,1);
		q1.methodA();
		q1.methodA();
	}

}
