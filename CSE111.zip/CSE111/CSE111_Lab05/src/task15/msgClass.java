package task15;

public class msgClass {
	
	public int content;

}
