package task15;

public class MainT15 {
	
	public static void main(String[] args) {
		
		Q5 q = new Q5();
		q.methodA();
	}

}
