package task13;

public class msgClass {
	public int content;

}
