package task06;

public class msgClass {
	public int content;
}
