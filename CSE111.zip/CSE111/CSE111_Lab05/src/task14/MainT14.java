package task14;

public class MainT14 {
	
	public static void main(String[] args) {
		
		FinalT6A q1 = new FinalT6A(5,6);
		q1.methodA();
		q1.methodA();
	}

}
