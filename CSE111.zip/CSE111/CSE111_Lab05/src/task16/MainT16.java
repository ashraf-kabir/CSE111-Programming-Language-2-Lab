package task16;

public class MainT16 {

	public static void main(String[] args) {
		
		FinalT6A q1 = new FinalT6A(3,2);
		FinalT6A q2 = new FinalT6A(2,3);
		q1.methodA();
		q2.methodA();
		
	}

}
