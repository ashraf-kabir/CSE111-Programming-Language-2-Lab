package task09;

public class Main {
	
	public static void main(String[] args){
		Scope q2 = new Scope();
		q2.met1();
		//q2.met2();
		q2.met1();
		//q2.met2();
		
	}

}
