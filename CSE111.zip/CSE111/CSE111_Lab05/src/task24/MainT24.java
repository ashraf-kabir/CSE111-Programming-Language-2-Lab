package task24;

public class MainT24 {

	public static void main(String[] args) {
		
		Q5 q = new Q5();
		q.methodA();
	}

}
