package task24;

public class msgClass {
	
	public int content;

}
