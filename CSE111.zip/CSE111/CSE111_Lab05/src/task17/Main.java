package task17;

public class Main {

	public static void main(String[] args) {
		
		MidQ3A obj = new MidQ3A();
		obj.methodA();
	}

}
