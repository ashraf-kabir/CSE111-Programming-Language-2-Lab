package task18;

public class MainT18 {

	public static void main(String[] args) {
		
		MidQ3B q = new MidQ3B();
		q.methodA();
	}

}
