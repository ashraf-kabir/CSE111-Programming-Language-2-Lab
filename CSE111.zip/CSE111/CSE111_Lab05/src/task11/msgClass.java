package task11;

public class msgClass {
	
	public int content;
	
}
