package task11;

public class MainT011 {
	
	public static void main(String[] args) {
		
		Q5 q = new Q5();
		q.methodA();
	}

}
