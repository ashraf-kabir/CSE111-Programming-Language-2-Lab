package task05;

import java.util.Scanner;

public class Task05 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Input a word:");
		String str1=sc.nextLine();
		
		String str2 = "==THE END==";
		
		System.out.println(str1);
		System.out.println(str1+str2);
		System.out.println(str1);
	}

}
