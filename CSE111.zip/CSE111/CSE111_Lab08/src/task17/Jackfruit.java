package task17;

public class Jackfruit extends Fruit {
	
	public Jackfruit(){
	    super(false, "Jackfruit");  
	}
	
	public String toString(){
	    return "Jackfruits are good for you";  
	}

}
