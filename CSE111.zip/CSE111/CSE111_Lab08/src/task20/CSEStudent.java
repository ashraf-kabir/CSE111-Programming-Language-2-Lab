package task20;

public class CSEStudent extends Student {
	
	public String msg;
	
    public CSEStudent(){
        this.msg = "I want to transfer to CSE";
    }
    public String shout(){
        return msg;
    }

}
