package task22;

public class Cat extends Animal {
	
	public Cat(String s){
        super(s);
    }

}
