package task22;

public class Dog extends Animal {
	
	public Dog(String s){
        super(s);
    }

}
