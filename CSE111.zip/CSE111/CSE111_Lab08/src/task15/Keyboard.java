package task15;

public class Keyboard {
	
	public void play(){
		System.out.println("In the playing method of Keyboard");	  
	}
	public void adjust(){
		System.out.println("Keyboard t t t in adjust");
	}

}
