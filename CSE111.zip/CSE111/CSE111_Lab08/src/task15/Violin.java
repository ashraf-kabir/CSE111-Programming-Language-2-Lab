package task15;

public class Violin {
	
	public void play(){
		System.out.println("In the playing method of Violin");
	}
	public void adjust(){
		System.out.println("Violin t t t in adjust");
	}

}
