package task15;

public class Guiter {
	
	public void play(){
		System.out.println("In the playing method of Guiter"); 
	}
	public void adjust(){
		System.out.println("Guiter t t t in adjust");  
	}

}
