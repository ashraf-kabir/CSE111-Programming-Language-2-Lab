package task15;

public abstract class Instrument {
	
	public abstract void play();
	public abstract void adjust();
	
	public void compose(){
		
	}

}
