package task15;

public class Test {
	
    public static void printingmethod(Instrument s){
        //s.play();
        //s.adjust();
    }
    
	public static void main(String[] args) {
		//printingmethod(new Guiter());
		//printingmethod(new  Violin());
		//printingmethod(new  Keyboard());
	}

}
