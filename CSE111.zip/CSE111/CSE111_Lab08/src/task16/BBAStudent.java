package task16;

public class BBAStudent extends Student{
	
	public BBAStudent() {
		setName("Default BBA Student");
		setDepartment("BBA");
	}
	public BBAStudent(String s) {
		setName(s);
		setDepartment("BBA");
	}

}
